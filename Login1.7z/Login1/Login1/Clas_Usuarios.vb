﻿Public Class Clas_Usuarios
    Public Property Usuario As String
    Public Property clave As String
    Public Property correo As String

End Class
