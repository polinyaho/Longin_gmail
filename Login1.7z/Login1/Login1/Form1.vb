﻿
Public Class FrmLogin
    Private Function Aleatorio(Minimo As Long, Maximo As Long) As Long
        Randomize()
        Aleatorio = CLng((Minimo - Maximo) * Rnd() + Maximo)
    End Function
    Private Function llenarLista() As List(Of Clas_Usuarios)
        Dim Origen As New System.Collections.Generic.List(Of Clas_Usuarios)

        Dim dato As New Clas_Usuarios
        With dato
            .clave = "Po123"
            .correo = "polin_yaho@hotmail.com"
        End With

        Origen.Add(dato)
        dato = New Clas_Usuarios
        With dato
            .clave = "L123"
            .correo = "polinyaho@gmail.com"

        End With

        Origen.Add(dato)
        'etcetera
        Return Origen
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ButtonX1_Click(sender As Object, e As EventArgs) Handles ButtonX1.Click


        Dim Class_correo As New Clas__correo

        Dim lista_usuario As List(Of Clas_Usuarios) = llenarLista()

        Dim Codigo As Integer
        Dim Lis_usu = (From Logoe In lista_usuario
                       Select New With {.correo = Logoe.correo, .clave = Logoe.clave}).ToList

        If Lis_usu.Where(Function(W) W.correo = txtusuario.Text And W.clave = txtpassword.Text).Any Then
            Codigo = Aleatorio(1, 1000)
            Class_correo.enviarCorreo("polinyaho@gmail.com", "Apl_123456", Codigo, "envio", txtusuario.Text)
        Else
            MsgBox("Usuario o clave Incorrecto. ")
        End If
        If Txtcodigo.Text = Codigo.ToString Then
            MsgBox("Bienvenido al Sistema ")

        End If
    End Sub
End Class
